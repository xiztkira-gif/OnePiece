package com.onepiece.optimizer

import android.content.Context
import android.content.Intent
import android.os.BatteryManager
import android.os.Bundle
import android.os.PowerManager
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Bg = Color(0xFF050607)
private val Card = Color(0xFF101214)
private val Accent = Color(0xFF63FF8A)
private val Muted = Color(0xFF8A9198)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { OnePieceApp() }
    }
}

@Composable
fun OnePieceApp() {
    val context = LocalContext.current
    var optimized by remember { mutableStateOf(false) }
    var battery by remember { mutableIntStateOf(readBattery(context)) }

    MaterialTheme(
        colorScheme = darkColorScheme(
            background = Bg,
            surface = Card,
            primary = Accent,
            onPrimary = Color.Black,
            onBackground = Color.White,
            onSurface = Color.White
        )
    ) {
        Surface(
            modifier = Modifier.fillMaxSize(),
            color = Bg
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(horizontal = 22.dp, vertical = 18.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Spacer(Modifier.height(22.dp))

                Text(
                    "ONE PIECE",
                    fontSize = 28.sp,
                    fontWeight = FontWeight.ExtraBold,
                    letterSpacing = 4.sp,
                    color = Color.White
                )
                Text(
                    "OFFLINE DEVICE OPTIMIZER",
                    fontSize = 10.sp,
                    letterSpacing = 2.sp,
                    color = Muted
                )

                Spacer(Modifier.height(34.dp))

                Box(
                    modifier = Modifier
                        .size(190.dp)
                        .background(Color(0xFF0C1710), RoundedCornerShape(95.dp)),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(
                            "$battery%",
                            fontSize = 48.sp,
                            fontWeight = FontWeight.Bold,
                            color = Accent
                        )
                        Text("BATTERY", color = Muted, fontSize = 11.sp)
                    }
                }

                Spacer(Modifier.height(30.dp))

                Button(
                    onClick = {
                        optimized = true
                        battery = readBattery(context)
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(62.dp),
                    shape = RoundedCornerShape(18.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = Accent,
                        contentColor = Color.Black
                    )
                ) {
                    Text(
                        if (optimized) "OPTIMIZED ✓" else "OPTIMIZE NOW",
                        fontSize = 17.sp,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 1.sp
                    )
                }

                Spacer(Modifier.height(18.dp))

                StatusCard(
                    "Battery saver",
                    "Prepare power-saving controls",
                    optimized
                )
                StatusCard(
                    "Background activity",
                    "Open Android battery controls",
                    false
                )
                StatusCard(
                    "Smoothness",
                    "Open display / animation controls",
                    false
                )

                Spacer(Modifier.weight(1f))

                OutlinedButton(
                    onClick = {
                        context.startActivity(
                            Intent(Settings.ACTION_BATTERY_SAVER_SETTINGS)
                        )
                    },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp)
                ) {
                    Text("OPEN BATTERY SETTINGS")
                }

                Spacer(Modifier.height(10.dp))

                Text(
                    "100% offline • No ads • No internet permission",
                    color = Muted,
                    fontSize = 11.sp
                )
            }
        }
    }
}

@Composable
private fun StatusCard(title: String, subtitle: String, done: Boolean) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 5.dp)
            .background(Card, RoundedCornerShape(16.dp))
            .padding(17.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(Modifier.weight(1f)) {
            Text(title, fontWeight = FontWeight.SemiBold, color = Color.White)
            Text(subtitle, color = Muted, fontSize = 11.sp)
        }
        Text(
            if (done) "DONE" else "READY",
            color = if (done) Accent else Muted,
            fontSize = 10.sp,
            fontWeight = FontWeight.Bold
        )
    }
}

private fun readBattery(context: Context): Int {
    val manager = context.getSystemService(Context.BATTERY_SERVICE) as BatteryManager
    return manager.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)
}
