# One Piece — GitHub APK Build

This project is configured to build the Android debug APK automatically with GitHub Actions.

## Phone-only build

1. Create a GitHub account or sign in.
2. Create a new repository, for example `OnePiece`.
3. Upload all files/folders from this project ZIP to the repository.
   - Make sure `.github/workflows/build-apk.yml` is included.
   - Do not upload the outer `OnePiece_GitHub` folder itself as an extra nesting level.
4. Open the repository's **Actions** tab.
5. Select **Build One Piece APK**.
6. Tap **Run workflow**.
7. Wait for the workflow to finish successfully.
8. Open the completed workflow run.
9. Under **Artifacts**, download `OnePiece-APK`.
10. Extract the downloaded artifact and install `OnePiece.apk` on your Realme.

## Automatic builds

The workflow also runs whenever you push changes to `main` or `master`.

## Important

This produces a debug APK. It is suitable for installing/testing on your own phone, but it is not a Play Store release build.

The app does not request INTERNET permission and is designed to work offline.

A normal Android app cannot directly modify protected Realme kernel/CPU settings or arbitrarily terminate other apps. The optimizer therefore only uses public Android capabilities and settings shortcuts.
