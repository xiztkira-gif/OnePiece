# One Piece

Offline Android battery/smoothness companion for Realme devices.

## Important Android limitation

A normal third-party Android application cannot directly:
- change CPU governors
- force-close arbitrary third-party apps
- alter kernel parameters
- change protected Realme system settings
- magically increase battery capacity

One Piece therefore uses only public Android APIs and settings intents. It does not require root or internet access.

## Build

Open this project in Android Studio (Ladybug or newer), let Gradle sync, then:

Build > Build Bundle(s) / APK(s) > Build APK(s)

The debug APK will be generated under:
app/build/outputs/apk/debug/app-debug.apk

## Current version

- AMOLED-style dark UI
- One-tap optimization state
- Battery percentage
- Offline operation
- Battery settings shortcut
- No INTERNET permission
- No ads
- No root requirement

The project is intentionally conservative so it does not claim to perform operations Android does not permit.
